from django.conf import settings
from django.db import models
U = settings.AUTH_USER_MODEL
class LinkedInConnection(models.Model):
    user = models.OneToOneField(U, on_delete=models.CASCADE, related_name="linkedin")
    member_sub = models.CharField(max_length=100); name = models.CharField(max_length=200, blank=True)
    email = models.EmailField(blank=True); picture = models.URLField(blank=True)
    token_encrypted = models.TextField(); expires_at = models.DateTimeField(null=True)
    scopes = models.CharField(max_length=300, blank=True); connected_at = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=20, default="active")  # active/expired/revoked
class BusinessProfile(models.Model):
    user = models.OneToOneField(U, on_delete=models.CASCADE)
    agency = models.CharField(max_length=200, default="HishiTalent Hub")
    services = models.TextField(default="Recruitment, staffing, and job placement services")
    countries = models.CharField(max_length=200, default="United States")
    industries = models.TextField(default="IT, software development, SaaS, consulting, technology startups")
    titles = models.TextField(default="Founder, CEO, CTO, HR Manager, Hiring Manager, Talent Acquisition, Recruitment Manager")
    paused = models.BooleanField(default=False)  # master pause
    daily_send_limit = models.PositiveIntegerField(default=30)
    sequence_days = models.CharField(max_length=100, default="1,3,7,12")
class SearchJob(models.Model):
    owner = models.ForeignKey(U, on_delete=models.CASCADE); params = models.JSONField(default=dict)
    status = models.CharField(max_length=20, default="Queued"); message = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
class Lead(models.Model):
    TIERS = [("Hot","Hot"),("Warm","Warm"),("Cold","Cold")]
    STAGES = ["New","Qualified","Contacted","Replied","Meeting","Converted","Lost","Opted out"]
    owner = models.ForeignKey(U, on_delete=models.CASCADE)
    company = models.CharField(max_length=200); website = models.URLField(blank=True)
    contact_name = models.CharField(max_length=200, blank=True); title = models.CharField(max_length=200, blank=True)
    email = models.EmailField(blank=True); email_status = models.CharField(max_length=20, default="unverified")
    linkedin_url = models.URLField(blank=True); industry = models.CharField(max_length=100, blank=True)
    hiring_signal_url = models.URLField(blank=True); hiring_signal = models.TextField(blank=True)
    source = models.CharField(max_length=60, default="manual"); source_url = models.URLField(blank=True)
    collected_at = models.DateTimeField(auto_now_add=True); is_demo = models.BooleanField(default=False)
    score = models.PositiveSmallIntegerField(default=0); tier = models.CharField(max_length=5, choices=TIERS, default="Cold")
    evidence = models.JSONField(default=list); stage = models.CharField(max_length=20, default="New")
    tags = models.CharField(max_length=200, blank=True); notes = models.TextField(blank=True)
    class Meta:
        constraints = [models.UniqueConstraint(fields=["owner","company","email"], name="uniq_lead")]
class OutreachDraft(models.Model):
    KINDS = ["first_touch","partnership","discovery","meeting","follow_up","re_engagement"]
    lead = models.ForeignKey(Lead, on_delete=models.CASCADE, related_name="drafts")
    kind = models.CharField(max_length=20, default="first_touch"); subject = models.CharField(max_length=200)
    body = models.TextField(); status = models.CharField(max_length=20, default="draft")  # draft/approved/sent
    created_at = models.DateTimeField(auto_now_add=True)
class FollowUp(models.Model):
    lead = models.ForeignKey(Lead, on_delete=models.CASCADE, related_name="followups")
    draft = models.ForeignKey(OutreachDraft, null=True, blank=True, on_delete=models.SET_NULL)
    channel = models.CharField(max_length=10, default="email")  # email or task (LinkedIn manual)
    step_day = models.PositiveSmallIntegerField(); due_at = models.DateTimeField()
    status = models.CharField(max_length=15, default="scheduled")  # scheduled/sent/failed/cancelled/done
    idempotency_key = models.CharField(max_length=80, unique=True)
class AutomationLog(models.Model):
    owner = models.ForeignKey(U, on_delete=models.CASCADE); action = models.CharField(max_length=100)
    detail = models.TextField(blank=True); at = models.DateTimeField(auto_now_add=True)
