from django.contrib.auth import get_user_model
from django.test import TestCase
from .models import Lead, BusinessProfile, FollowUp
from .services.scoring import score_lead
from .tasks import schedule_sequence
class T(TestCase):
    def setUp(self):
        self.u = get_user_model().objects.create_user("a", password="x"); self.p = BusinessProfile.objects.create(user=self.u)
    def test_no_invented_signals(self):
        l = Lead.objects.create(owner=self.u, company="X"); s, tier, ev = score_lead(l, self.p); self.assertEqual((s, tier), (0, "Cold"))
    def test_hot_with_evidence(self):
        l = Lead.objects.create(owner=self.u, company="X", industry="SaaS", title="CTO", email="a@x.com", email_status="valid",
            hiring_signal="is hiring Python engineers", hiring_signal_url="https://x.com/jobs"); self.assertEqual(score_lead(l, self.p)[1], "Hot")
    def test_no_duplicate_schedule(self):
        l = Lead.objects.create(owner=self.u, company="X"); schedule_sequence(l, None); schedule_sequence(l, None); self.assertEqual(FollowUp.objects.count(), 4)
    def test_dashboard_requires_login(self): self.assertEqual(self.client.get("/").status_code, 302)
