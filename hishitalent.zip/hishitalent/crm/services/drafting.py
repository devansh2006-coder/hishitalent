from django.conf import settings
def _template(lead, profile, kind):
    who = lead.contact_name.split(" ")[0] if lead.contact_name else "there"
    hook = f"I noticed {lead.company} {lead.hiring_signal.strip()}." if lead.hiring_signal else f"I'm reaching out to {lead.company}."
    body = f"Hi {who},\n\n{hook} I'm with {profile.agency}, where we provide {profile.services.lower()} for technology teams.\n\nWould it be useful to share how we could support your hiring? Happy to keep it brief.\n\nBest regards"
    return f"Hiring support for {lead.company}", body
def generate(lead, profile, kind="first_touch"):
    """Uses OpenAI when configured, grounded ONLY in stored lead fields; else a template."""
    if not settings.OPENAI_API_KEY: return _template(lead, profile, kind)
    from openai import OpenAI
    facts = f"Company: {lead.company}; Contact: {lead.contact_name} ({lead.title}); Hiring signal: {lead.hiring_signal or 'none documented'}"
    r = OpenAI(api_key=settings.OPENAI_API_KEY).chat.completions.create(model=settings.OPENAI_MODEL, messages=[
        {"role":"system","content":f"Write a concise, professional {kind} outreach email from {profile.agency} ({profile.services}). Use ONLY the facts given; never invent facts. First line = subject."},
        {"role":"user","content":facts}])
    t = r.choices[0].message.content.strip().split("\n",1)
    return t[0].replace("Subject:","").strip(), (t[1].strip() if len(t)>1 else "")
