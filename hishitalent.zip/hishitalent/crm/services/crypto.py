from cryptography.fernet import Fernet
from django.conf import settings
def _f(): return Fernet(settings.TOKEN_ENCRYPTION_KEY.encode())
def encrypt(s): return _f().encrypt(s.encode()).decode()
def decrypt(s): return _f().decrypt(s.encode()).decode()
