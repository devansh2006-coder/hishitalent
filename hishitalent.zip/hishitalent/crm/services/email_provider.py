"""Replaceable provider interface. Implement GmailProvider / GraphProvider here with OAuth tokens."""
class EmailProvider:
    def send(self, user, to, subject, body): raise NotImplementedError
class NotConfiguredProvider(EmailProvider):
    def send(self, user, to, subject, body): raise RuntimeError("No email provider configured. Add Gmail API or Microsoft Graph in Settings.")
def get_provider(user): return NotConfiguredProvider()
