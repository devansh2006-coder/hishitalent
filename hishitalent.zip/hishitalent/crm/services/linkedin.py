"""LinkedIn OAuth 2.0. Default product = Sign In with LinkedIn (OpenID Connect).
Search, connections, inbox and messaging are NOT available with it; those need partner-program approval."""
import secrets, requests
from datetime import timedelta
from urllib.parse import urlencode
from django.conf import settings
from django.utils import timezone
from . import crypto
AUTH="https://www.linkedin.com/oauth/v2/authorization"; TOKEN="https://www.linkedin.com/oauth/v2/accessToken"
USERINFO="https://api.linkedin.com/v2/userinfo"; REVOKE="https://www.linkedin.com/oauth/v2/revoke"
class LinkedInError(Exception): pass
def auth_url(request):
    state = secrets.token_urlsafe(32); request.session["li_state"] = state; c = settings.LINKEDIN
    return AUTH+"?"+urlencode({"response_type":"code","client_id":c["CLIENT_ID"],"redirect_uri":c["REDIRECT_URI"],
        "state":state,"scope":c["SCOPES"]})
def exchange(request, code, state):
    expected = request.session.pop("li_state", None)
    if not expected or not secrets.compare_digest(expected, state or ""): raise LinkedInError("Invalid OAuth state (CSRF check failed).")
    c = settings.LINKEDIN
    r = requests.post(TOKEN, data={"grant_type":"authorization_code","code":code,"redirect_uri":c["REDIRECT_URI"],
        "client_id":c["CLIENT_ID"],"client_secret":c["CLIENT_SECRET"]}, timeout=15)
    if r.status_code != 200: raise LinkedInError(f"Token exchange failed ({r.status_code}).")
    return r.json()
def fetch_profile(access_token):
    r = requests.get(USERINFO, headers={"Authorization":f"Bearer {access_token}"}, timeout=15)
    if r.status_code == 401: raise LinkedInError("Token expired or revoked. Please reconnect.")
    if r.status_code != 200: raise LinkedInError(f"LinkedIn API error ({r.status_code}).")
    return r.json()
def save_connection(user, tok, profile):
    from crm.models import LinkedInConnection
    LinkedInConnection.objects.update_or_create(user=user, defaults=dict(member_sub=profile.get("sub",""),
        name=profile.get("name",""), email=profile.get("email",""), picture=profile.get("picture",""),
        token_encrypted=crypto.encrypt(tok["access_token"]), scopes=tok.get("scope",""), status="active",
        expires_at=timezone.now()+timedelta(seconds=int(tok.get("expires_in",0)))))
def disconnect(conn):
    c = settings.LINKEDIN
    try: requests.post(REVOKE, data={"client_id":c["CLIENT_ID"],"client_secret":c["CLIENT_SECRET"],
        "token":crypto.decrypt(conn.token_encrypted)}, timeout=15)
    except Exception: pass  # revoke is best-effort; always delete local token
    conn.delete()
CAPABILITIES = {"Sign in & basic profile (OpenID Connect)":True,"Search people/companies":False,
    "Read connections":False,"Read/send messages":False,"Send connection requests":False}
