"""Evidence-based scoring. Only awards points for data actually present on the record; never invents signals."""
import re
TECH = re.compile(r"python|java|react|node|aws|devops|data|ml|ai|cloud|engineer|developer", re.I)
DECISION = re.compile(r"founder|ceo|cto|chief|hr|talent|recruit|hiring|people", re.I)
def score_lead(lead, profile):
    pts, ev = 0, []
    inds = [i.strip().lower() for i in profile.industries.split(",") if i.strip()]
    if lead.industry and any(i in lead.industry.lower() or lead.industry.lower() in i for i in inds): pts+=20; ev.append("+20 industry matches target")
    if lead.hiring_signal and lead.hiring_signal_url: pts+=25; ev.append(f"+25 documented hiring signal: {lead.hiring_signal_url}")
    if lead.hiring_signal and TECH.search(lead.hiring_signal): pts+=15; ev.append("+15 technology roles in hiring signal")
    if lead.title and DECISION.search(lead.title): pts+=15; ev.append(f"+15 decision-maker title: {lead.title}")
    if lead.industry: pts+=5; ev.append("+5 service compatibility (industry known)")
    if lead.email_status == "valid": pts+=15; ev.append("+15 verified email")
    elif lead.email: pts+=5; ev.append("+5 email present but unverified")
    if lead.stage in ("Replied","Meeting"): pts+=5; ev.append("+5 previous engagement")
    pts = min(pts,100); tier = "Hot" if pts>=70 else "Warm" if pts>=40 else "Cold"
    return pts, tier, ev
