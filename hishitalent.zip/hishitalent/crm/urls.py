from django.urls import path, include
from rest_framework import routers, serializers, viewsets
from . import views
from .models import Lead
class LeadSer(serializers.ModelSerializer):
    class Meta: model = Lead; exclude = ["owner"]
class LeadVS(viewsets.ModelViewSet):
    serializer_class = LeadSer
    def get_queryset(self): return Lead.objects.filter(owner=self.request.user)
    def perform_create(self, s): s.save(owner=self.request.user)
router = routers.DefaultRouter(); router.register("leads", LeadVS, basename="api-lead")
urlpatterns = [path("", views.dashboard, name="dashboard"), path("linkedin/", views.linkedin_page, name="linkedin"),
 path("linkedin/connect/", views.linkedin_connect, name="linkedin_connect"), path("linkedin/callback/", views.linkedin_callback),
 path("linkedin/disconnect/", views.linkedin_disconnect, name="linkedin_disconnect"), path("leads/", views.leads, name="leads"),
 path("leads/import/", views.import_csv, name="import"), path("leads/<int:pk>/", views.lead_detail, name="lead_detail"),
 path("leads/<int:pk>/score/", views.lead_score, name="lead_score"), path("leads/<int:pk>/draft/", views.lead_draft, name="lead_draft"),
 path("drafts/<int:pk>/approve/", views.draft_approve, name="draft_approve"), path("pause/", views.master_pause, name="pause"),
 path("delete-data/", views.delete_my_data, name="delete_data"), path("api/", include(router.urls))]
