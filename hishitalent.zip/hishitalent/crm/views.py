import csv, io
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db.models import Count, Q
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.http import require_POST
from .models import *
from .services import linkedin as li, scoring, drafting
from .tasks import schedule_sequence
def _prof(u): return BusinessProfile.objects.get_or_create(user=u)[0]
@login_required
def dashboard(request):
    L = Lead.objects.filter(owner=request.user)
    ctx = dict(total=L.count(), new=L.filter(stage="New").count(), qualified=L.filter(stage="Qualified").count(),
        hot=L.filter(tier="Hot").count(), sent=FollowUp.objects.filter(lead__owner=request.user, status="sent").count(),
        replies=L.filter(stage="Replied").count(), meetings=L.filter(stage="Meeting").count(), conversions=L.filter(stage="Converted").count(),
        overdue=FollowUp.objects.filter(lead__owner=request.user, status="scheduled", due_at__lt=timezone.now()).count(),
        profile=_prof(request.user), logs=AutomationLog.objects.filter(owner=request.user)[:10])
    return render(request, "crm/dashboard.html", ctx)
@login_required
def linkedin_page(request):
    return render(request, "crm/linkedin.html", {"conn": getattr(request.user, "linkedin", None), "caps": li.CAPABILITIES})
@login_required
def linkedin_connect(request): return redirect(li.auth_url(request))
@login_required
def linkedin_callback(request):
    if request.GET.get("error"):
        messages.error(request, "LinkedIn authorization was cancelled or denied."); return redirect("linkedin")
    try:
        tok = li.exchange(request, request.GET.get("code"), request.GET.get("state"))
        li.save_connection(request.user, tok, li.fetch_profile(tok["access_token"]))
        messages.success(request, "LinkedIn connected.")
    except li.LinkedInError as e: messages.error(request, str(e))
    return redirect("linkedin")
@login_required
@require_POST
def linkedin_disconnect(request):
    if hasattr(request.user, "linkedin"): li.disconnect(request.user.linkedin)
    messages.info(request, "LinkedIn disconnected and token deleted."); return redirect("linkedin")
@login_required
def leads(request):
    qs = Lead.objects.filter(owner=request.user); q = request.GET.get("q"); tier = request.GET.get("tier")
    if q: qs = qs.filter(Q(company__icontains=q)|Q(contact_name__icontains=q)|Q(tags__icontains=q))
    if tier: qs = qs.filter(tier=tier)
    qs = qs.order_by(request.GET.get("sort", "-score"))
    if request.GET.get("export"):
        r = HttpResponse(content_type="text/csv"); r["Content-Disposition"]='attachment; filename="leads.csv"'
        w = csv.writer(r); w.writerow(["company","contact","title","email","email_status","score","tier","stage","source","source_url"])
        for l in qs: w.writerow([l.company,l.contact_name,l.title,l.email,l.email_status,l.score,l.tier,l.stage,l.source,l.source_url]); 
        return r
    return render(request, "crm/leads.html", {"leads": qs[:500]})
@login_required
def lead_detail(request, pk):
    lead = get_object_or_404(Lead, pk=pk, owner=request.user)
    if request.method == "POST":
        lead.notes = request.POST.get("notes",""); lead.tags = request.POST.get("tags",""); lead.stage = request.POST.get("stage", lead.stage); lead.save()
        messages.success(request, "Saved.")
    return render(request, "crm/lead_detail.html", {"lead": lead, "stages": Lead.STAGES})
@login_required
@require_POST
def lead_score(request, pk):
    lead = get_object_or_404(Lead, pk=pk, owner=request.user)
    lead.score, lead.tier, lead.evidence = scoring.score_lead(lead, _prof(request.user)); lead.save(); return redirect("lead_detail", pk=pk)
@login_required
@require_POST
def lead_draft(request, pk):
    lead = get_object_or_404(Lead, pk=pk, owner=request.user); kind = request.POST.get("kind","first_touch")
    s, b = drafting.generate(lead, _prof(request.user), kind); OutreachDraft.objects.create(lead=lead, kind=kind, subject=s, body=b)
    return redirect("lead_detail", pk=pk)
@login_required
@require_POST
def draft_approve(request, pk):
    d = get_object_or_404(OutreachDraft, pk=pk, lead__owner=request.user)
    d.subject = request.POST.get("subject", d.subject); d.body = request.POST.get("body", d.body); d.status = "approved"; d.save()
    schedule_sequence(d.lead, d); AutomationLog.objects.create(owner=request.user, action="approved", detail=f"draft {d.pk}")
    messages.success(request, "Approved. Follow-up sequence scheduled."); return redirect("lead_detail", pk=d.lead_id)
@login_required
def import_csv(request):
    if request.method == "POST" and request.FILES.get("file"):
        rows = csv.DictReader(io.StringIO(request.FILES["file"].read().decode("utf-8-sig"))); n = 0
        for r in rows:
            if not r.get("company"): continue
            _, c = Lead.objects.get_or_create(owner=request.user, company=r["company"].strip(), email=(r.get("email") or "").strip().lower(),
                defaults=dict(contact_name=r.get("contact_name",""), title=r.get("title",""), industry=r.get("industry",""), website=r.get("website",""),
                hiring_signal=r.get("hiring_signal",""), hiring_signal_url=r.get("hiring_signal_url",""), source="csv_import", source_url=r.get("source_url","")))
            n += c
        messages.success(request, f"Imported {n} new leads (duplicates skipped).")
        return redirect("leads")
    return render(request, "crm/import.html")
@login_required
@require_POST
def master_pause(request):
    p = _prof(request.user); p.paused = not p.paused; p.save()
    AutomationLog.objects.create(owner=request.user, action="master_pause", detail=str(p.paused)); return redirect("dashboard")
@login_required
@require_POST
def delete_my_data(request):
    Lead.objects.filter(owner=request.user).delete(); messages.info(request, "All your lead data was deleted."); return redirect("dashboard")
