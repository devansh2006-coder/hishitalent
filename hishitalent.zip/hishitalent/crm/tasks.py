from datetime import timedelta
from celery import shared_task
from django.utils import timezone
from .models import FollowUp, AutomationLog, BusinessProfile, Lead
from .services.email_provider import get_provider
STOP = ("Replied","Meeting","Converted","Opted out","Lost")
@shared_task
def process_due_followups():
    now = timezone.now()
    for fu in FollowUp.objects.filter(status="scheduled", due_at__lte=now).select_related("lead","draft"):
        lead, owner = fu.lead, fu.lead.owner
        prof, _ = BusinessProfile.objects.get_or_create(user=owner)
        if prof.paused: continue
        if lead.stage in STOP:
            fu.status="cancelled"; fu.save(); AutomationLog.objects.create(owner=owner, action="cancelled", detail=f"{lead} stage={lead.stage}"); continue
        if fu.channel != "email" or not lead.email or not fu.draft or fu.draft.status != "approved":
            continue  # tasks/reminders and unapproved drafts are surfaced in the calendar for manual action
        sent_today = FollowUp.objects.filter(lead__owner=owner, status="sent", due_at__date=now.date()).count()
        if sent_today >= prof.daily_send_limit: continue
        try:
            get_provider(owner).send(owner, lead.email, fu.draft.subject, fu.draft.body)
            fu.status="sent"; AutomationLog.objects.create(owner=owner, action="sent", detail=f"day {fu.step_day} -> {lead.email}")
        except Exception as e:
            fu.status="failed"; AutomationLog.objects.create(owner=owner, action="failed", detail=str(e))
        fu.save()
def schedule_sequence(lead, draft, start=None):
    prof, _ = BusinessProfile.objects.get_or_create(user=lead.owner); start = start or timezone.now()
    for d in [int(x) for x in prof.sequence_days.split(",")]:
        FollowUp.objects.get_or_create(idempotency_key=f"{lead.pk}-{d}", defaults=dict(lead=lead, draft=draft,
            step_day=d, due_at=start+timedelta(days=d-1), channel="email" if lead.email else "task"))
