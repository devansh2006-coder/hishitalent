import os, dj_database_url
from pathlib import Path
from dotenv import load_dotenv
BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BASE_DIR / ".env")
SECRET_KEY = os.environ["DJANGO_SECRET_KEY"]
DEBUG = os.getenv("DJANGO_DEBUG", "0") == "1"
ALLOWED_HOSTS = os.getenv("ALLOWED_HOSTS", "localhost").split(",")
INSTALLED_APPS = ["django.contrib.admin","django.contrib.auth","django.contrib.contenttypes",
 "django.contrib.sessions","django.contrib.messages","django.contrib.staticfiles","rest_framework","crm"]
MIDDLEWARE = ["django.middleware.security.SecurityMiddleware","whitenoise.middleware.WhiteNoiseMiddleware",
 "django.contrib.sessions.middleware.SessionMiddleware","django.middleware.common.CommonMiddleware",
 "django.middleware.csrf.CsrfViewMiddleware","django.contrib.auth.middleware.AuthenticationMiddleware",
 "django.contrib.messages.middleware.MessageMiddleware","django.middleware.clickjacking.XFrameOptionsMiddleware"]
ROOT_URLCONF = "config.urls"
TEMPLATES = [{"BACKEND":"django.template.backends.django.DjangoTemplates","APP_DIRS":True,
 "OPTIONS":{"context_processors":["django.template.context_processors.request",
 "django.contrib.auth.context_processors.auth","django.contrib.messages.context_processors.messages"]}}]
DATABASES = {"default": dj_database_url.config(default=os.getenv("DATABASE_URL"), conn_max_age=600)}
STATIC_URL = "static/"; STATIC_ROOT = BASE_DIR / "staticfiles"
DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"
LOGIN_URL = "login"; LOGIN_REDIRECT_URL = "dashboard"; TIME_ZONE = "UTC"; USE_TZ = True
REST_FRAMEWORK = {"DEFAULT_AUTHENTICATION_CLASSES":["rest_framework.authentication.SessionAuthentication"],
 "DEFAULT_PERMISSION_CLASSES":["rest_framework.permissions.IsAuthenticated"],
 "DEFAULT_THROTTLE_CLASSES":["rest_framework.throttling.UserRateThrottle"],
 "DEFAULT_THROTTLE_RATES":{"user":"300/hour"}}
CELERY_BROKER_URL = os.getenv("REDIS_URL", "redis://localhost:6379/0")
CELERY_BEAT_SCHEDULE = {"process-followups":{"task":"crm.tasks.process_due_followups","schedule":300}}
if not DEBUG:
    SECURE_SSL_REDIRECT = True; SESSION_COOKIE_SECURE = True; CSRF_COOKIE_SECURE = True
    SECURE_HSTS_SECONDS = 31536000; SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO","https")
LINKEDIN = {"CLIENT_ID":os.getenv("LINKEDIN_CLIENT_ID",""),"CLIENT_SECRET":os.getenv("LINKEDIN_CLIENT_SECRET",""),
 "REDIRECT_URI":os.getenv("LINKEDIN_REDIRECT_URI",""),"SCOPES":os.getenv("LINKEDIN_SCOPES","openid profile email")}
TOKEN_ENCRYPTION_KEY = os.getenv("TOKEN_ENCRYPTION_KEY","")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY",""); OPENAI_MODEL = os.getenv("OPENAI_MODEL","gpt-4o-mini")
