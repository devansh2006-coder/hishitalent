# HishiTalent AI (MVP)
## Local setup
    python -m venv .venv && source .venv/bin/activate && pip install -r requirements.txt
    cp .env.example .env   # fill in values (needs PostgreSQL + Redis)
    python manage.py makemigrations crm && python manage.py migrate && python manage.py createsuperuser
    python manage.py test
    python manage.py runserver
    celery -A config worker -l info   # and in another shell:  celery -A config beat -l info
## LinkedIn
1. Create an app at developers.linkedin.com; add product **Sign In with LinkedIn using OpenID Connect**.
2. Set redirect URL to LINKEDIN_REDIRECT_URI. Scopes: openid profile email.
3. NOT available without LinkedIn partner approval: people/company search, connections, inbox, messaging. The app shows this and uses CSV import / manual URLs instead.
## Deploy (Render/Railway/VPS)
Web: `gunicorn config.wsgi` (run `collectstatic`, `migrate`); Worker: celery worker; Beat: celery beat; add Postgres + Redis; set env vars from .env.example; serve over HTTPS.
## Status: built vs. still to do
Built: auth, LinkedIn OAuth (CSRF state, encrypted tokens, revoke), CSV import + dedupe, evidence-based scoring, AI/template drafts with approval, follow-up scheduler (idempotent, pause, stop-on-reply, daily cap), audit log, CSV export, REST API, tests.
To do: Gmail/Graph provider (crm/services/email_provider.py), data-provider + email-verification adapters, search-job UI/workers, calendar, inbox reply classification, pipeline board, analytics charts, roles/permissions.
